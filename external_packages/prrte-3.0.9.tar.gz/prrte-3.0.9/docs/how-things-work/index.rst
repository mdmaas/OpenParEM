How Things Work
===============

This section explains how some of the functions inside
PRRTE perform their job. If you have questions about, for
example, how session directory trees work, then you will
find information on that subject here.

.. toctree::
   :maxdepth: 2

   session_dirs.rst
