PRRTE v1.x series
=================

This file contains all the NEWS updates for all the PRTE v1.x
series, in reverse chronological order.

1.0.0 -- 17 Jul 2019
----------------------

Initial public release  - not production intended
