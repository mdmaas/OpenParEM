Config file manual pages (section 5)
====================================

.. toctree::
   :maxdepth: 1

   prte.5.rst
