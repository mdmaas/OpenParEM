.. _man5-prte:

prte
====

PMIx Reference Runtime Environment (PRRTE) - General information

.. admonition:: PRRTE Docs TODO
   :class: error

   Need to write this man page.
