.. -*- rst -*-

   Copyright (c) 2022-2023 Nanook Consulting.  All rights reserved.
   Copyright (c) 2023 Jeffrey M. Squyres.  All rights reserved.

   $COPYRIGHT$

   Additional copyrights may follow

   $HEADER$

.. The following line is included so that Sphinx won't complain
   about this file not being directly included in some toctree

Comma-delimited list of additional signals (names or integers) to
forward to application processes (``none`` = forward
nothing). Signals provided by default include SIGTSTP, SIGUSR1,
SIGUSR2, SIGABRT, SIGALRM, and SIGCONT.
