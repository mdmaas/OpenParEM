Building PMIx applications
==========================

The simplest way to compile and link PMIx applications is to use the
PMIx "wrapper" compilers.

.. toctree::
   :maxdepth: 1

   quickstart
   customizing-wrappers
   extracting-wrapper-flags
   deprecation-warnings
   building-static-apps
