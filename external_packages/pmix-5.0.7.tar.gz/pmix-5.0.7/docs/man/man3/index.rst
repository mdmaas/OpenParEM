APIs (section 3)
================

.. admonition:: PMIx Docs TODO
   :class: error

   Need to supply all the rest of the man pages for section 3.

.. toctree::
   :maxdepth: 1

   PMIx_Abort.3.rst
   PMIx_Init.3.rst
   PMIx_Finalize.3.rst
