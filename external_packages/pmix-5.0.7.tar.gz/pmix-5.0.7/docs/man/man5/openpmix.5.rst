.. _man5-openpmix:

OpenPMIx
========

Write more here.

.. admonition:: PMIx Docs TODO
   :class: error

   Need to write this man page.
