Config file manual pages (section 5)
====================================

.. toctree::
   :maxdepth: 1

   openpmix.5.rst
