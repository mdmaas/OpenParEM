Commands (section 1)
====================

.. toctree::
   :maxdepth: 1

   pmix_info.1.rst
   palloc.1.rst
   pattrs.1.rst
   pevent.1.rst
   plookup.1.rst
   pmixcc.1.rst
   pps.1.rst
   pquery.1.rst
